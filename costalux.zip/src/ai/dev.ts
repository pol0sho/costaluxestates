import { config } from 'dotenv';
config();

import '@/ai/flows/roi-estimation.ts';